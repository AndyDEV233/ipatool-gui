'use strict';

const $ = (id) => document.getElementById(id);
const state = {
  keychainConfigured: false,
  loggedIn: false,
  account: null,
  outputDir: '',
  defaultOutputDir: '',
  recommendedOutputDir: '',
  version: '',
  purchasePage: 1,
  lastPurchaseTotal: 0,
  currentTask: null,
  polling: null,
  versionsApp: null,
};

function esc(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function toast(message, type) {
  const el = document.createElement('div');
  el.className = 'toast' + (type ? ' ' + type : '');
  el.textContent = message;
  $('toasts').appendChild(el);
  setTimeout(() => el.remove(), type === 'err' ? 6000 : 3200);
}

async function api(path, options) {
  const opt = Object.assign({ headers: {} }, options || {});
  if (opt.body !== undefined && typeof opt.body !== 'string') {
    opt.headers['Content-Type'] = 'application/json';
    opt.body = JSON.stringify(opt.body);
  }
  const res = await fetch(path, opt);
  let data = null;
  try { data = await res.json(); } catch (e) { /* 忽略空响应 */ }
  if (!res.ok || (data && data.error)) {
    throw new Error((data && data.error) || ('请求失败（HTTP ' + res.status + '）'));
  }
  return data || {};
}

function setBusy(button, busy, busyText) {
  if (!button) return;
  if (busy) {
    button.dataset.label = button.textContent;
    button.disabled = true;
    button.innerHTML = '<span class="spinner"></span>' + esc(busyText || button.dataset.label);
  } else {
    button.disabled = false;
    button.textContent = button.dataset.label || button.textContent;
  }
}

/* ---------------- 视图切换 ---------------- */
document.querySelectorAll('.nav-item').forEach((item) => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach((n) => n.classList.remove('active'));
    document.querySelectorAll('.view').forEach((v) => v.classList.remove('active'));
    item.classList.add('active');
    document.querySelector('.view[data-view="' + item.dataset.view + '"]').classList.add('active');
  });
});

/* ---------------- 账号状态 ---------------- */
async function refreshState() {
  const data = await api('/api/state');
  Object.assign(state, data);

  $('account-name').textContent = state.loggedIn ? (state.account.name || '已登录') : '未登录';
  $('account-mail').textContent = state.loggedIn ? (state.account.email || '') : '请先登录 Apple ID';
  $('login-btn').classList.toggle('hidden', state.loggedIn);
  $('logout-btn').classList.toggle('hidden', !state.loggedIn);

  const keychainStatus = $('keychain-status');
  if (state.keychainConfigured) {
    keychainStatus.textContent = '钥匙串密码已设置。';
    keychainStatus.className = 'status-line ok';
  } else {
    keychainStatus.textContent = '尚未设置钥匙串密码，登录前请先设置。';
    keychainStatus.className = 'status-line err';
  }

  $('outputdir-input').value = state.outputDir || '';
  $('outputdir-status').textContent = '当前下载目录：' + state.effectiveOutputDir;
  $('about-line').textContent = '版本 ' + state.version;
}

/* ---------------- 应用卡片 ---------------- */
const AVATAR_COLORS = ['#4f46e5', '#0ea5e9', '#059669', '#d97706', '#db2777', '#7c3aed', '#0891b2', '#e11d48'];

function avatarColor(seed) {
  let hash = 0;
  const text = String(seed || '');
  for (let i = 0; i < text.length; i++) hash = (hash * 31 + text.charCodeAt(i)) >>> 0;
  return AVATAR_COLORS[hash % AVATAR_COLORS.length];
}

function priceTag(app) {
  if (!app.price || app.price <= 0) return '<span class="tag tag-ok">免费</span>';
  return '<span class="tag">¥ ' + esc(app.price) + '</span>';
}

function appCard(app) {
  const name = app.trackName || app.bundleId || ('应用 #' + app.trackId);
  const tags = [];
  if (app.trackId) tags.push('<span class="tag tag-accent">ID ' + esc(app.trackId) + '</span>');
  if (app.version) tags.push('<span class="tag">版本 ' + esc(app.version) + '</span>');
  tags.push(priceTag(app));
  if (Array.isArray(app.platforms) && app.platforms.length) {
    tags.push('<span class="tag">' + esc(app.platforms.join(' / ')) + '</span>');
  }

  const el = document.createElement('div');
  el.className = 'app-card';
  el.innerHTML =
    '<div class="app-avatar" style="background:' + avatarColor(app.bundleId || app.trackId) + '">' +
      esc(String(name).trim().charAt(0).toUpperCase() || '?') +
    '</div>' +
    '<div class="app-info">' +
      '<div class="app-name">' + esc(name) + '</div>' +
      '<div class="app-meta">' + esc(app.bundleId || '') + '</div>' +
      '<div class="app-tags">' + tags.join('') + '</div>' +
    '</div>' +
    '<div class="app-actions">' +
      '<button class="btn btn-ghost btn-sm" data-action="versions">历史版本</button>' +
      '<button class="btn btn-primary btn-sm" data-action="download">下载</button>' +
    '</div>';

  el.querySelector('[data-action="download"]').addEventListener('click', (e) => startDownload(app, '', e.currentTarget));
  el.querySelector('[data-action="versions"]').addEventListener('click', () => openVersions(app));
  return el;
}

function renderList(container, apps, emptyText) {
  container.innerHTML = '';
  if (!apps || !apps.length) {
    const empty = document.createElement('div');
    empty.className = 'list-empty';
    empty.textContent = emptyText;
    container.appendChild(empty);
    return;
  }
  apps.forEach((app) => container.appendChild(appCard(app)));
}

/* ---------------- 搜索 ---------------- */
$('search-btn').addEventListener('click', doSearch);
$('search-term').addEventListener('keydown', (e) => { if (e.key === 'Enter') doSearch(); });

async function doSearch() {
  const term = $('search-term').value.trim();
  if (!term) { toast('请输入要搜索的应用名称', 'err'); return; }
  const button = $('search-btn');
  setBusy(button, true, '搜索中');
  try {
    const query = new URLSearchParams({
      term: term,
      limit: $('search-limit').value,
      platform: $('search-platform').value,
    });
    const data = await api('/api/search?' + query.toString());
    renderList($('search-results'), data.apps, '没有找到匹配的应用。');
  } catch (err) {
    toast(err.message, 'err');
    renderList($('search-results'), [], '搜索失败：' + err.message);
  } finally {
    setBusy(button, false);
  }
}

/* ---------------- 已购 ---------------- */
$('purchases-load').addEventListener('click', () => { state.purchasePage = 1; loadPurchases(); });
$('purchases-prev').addEventListener('click', () => {
  if (state.purchasePage <= 1) return;
  state.purchasePage -= 1;
  loadPurchases();
});
$('purchases-next').addEventListener('click', () => {
  state.purchasePage += 1;
  loadPurchases();
});

async function loadPurchases() {
  const button = $('purchases-load');
  setBusy(button, true, '加载中');
  try {
    const query = new URLSearchParams({
      page: String(state.purchasePage),
      limit: $('purchases-limit').value,
      platform: $('purchases-platform').value,
    });
    const data = await api('/api/purchases?' + query.toString());
    state.lastPurchaseTotal = data.totalCount || 0;
    $('purchases-page').textContent = '第 ' + (data.page || state.purchasePage) + ' 页 / 共 ' + state.lastPurchaseTotal + ' 个';
    renderList($('purchases-results'), data.apps, '这一页没有应用。');
  } catch (err) {
    toast(err.message, 'err');
  } finally {
    setBusy(button, false);
  }
}

/* ---------------- 历史版本 ---------------- */
function openVersions(app) {
  state.versionsApp = app;
  $('versions-title').textContent = app.trackName || app.bundleId || '';
  $('versions-list').innerHTML = '<div class="list-empty">正在获取版本列表…</div>';
  $('versions-modal').classList.remove('hidden');
  loadVersions(app);
}

async function loadVersions(app) {
  try {
    const query = new URLSearchParams({
      appId: app.trackId ? String(app.trackId) : '',
      bundleId: app.bundleId || '',
      platform: $('search-platform').value,
    });
    const data = await api('/api/versions?' + query.toString());
    const ids = data.ids || [];
    $('versions-title').textContent = (app.trackName || app.bundleId) + '，共 ' + ids.length + ' 个版本';
    const list = $('versions-list');
    list.innerHTML = '';
    if (!ids.length) {
      list.innerHTML = '<div class="list-empty">没有可用的历史版本。</div>';
      return;
    }
    ids.forEach((id) => {
      const item = document.createElement('div');
      item.className = 'version-item';
      item.innerHTML =
        '<span class="version-id">' + esc(id) + '</span>' +
        (String(id) === String(data.latest) ? '<span class="tag tag-ok">最新</span>' : '') +
        '<button class="btn btn-primary btn-sm">下载此版本</button>';
      item.querySelector('button').addEventListener('click', (e) => {
        startDownload(app, id, e.currentTarget);
      });
      list.appendChild(item);
    });
  } catch (err) {
    $('versions-list').innerHTML = '<div class="list-empty">获取失败：' + esc(err.message) + '</div>';
  }
}

$('versions-close').addEventListener('click', () => $('versions-modal').classList.add('hidden'));
$('versions-cancel').addEventListener('click', () => $('versions-modal').classList.add('hidden'));

/* ---------------- 登录 ---------------- */
$('login-btn').addEventListener('click', () => {
  $('login-error').classList.add('hidden');
  $('login-code-field').classList.add('hidden');
  $('login-modal').classList.remove('hidden');
  $('login-email').focus();
});
$('login-close').addEventListener('click', () => $('login-modal').classList.add('hidden'));
$('login-cancel').addEventListener('click', () => $('login-modal').classList.add('hidden'));
$('login-submit').addEventListener('click', submitLogin);
$('login-code').addEventListener('keydown', (e) => { if (e.key === 'Enter') submitLogin(); });

async function submitLogin() {
  const email = $('login-email').value.trim();
  const password = $('login-password').value;
  const authCode = $('login-code').value.trim();
  const error = $('login-error');
  error.classList.add('hidden');

  if (!email) { error.textContent = '请输入 Apple ID 邮箱。'; error.classList.remove('hidden'); return; }

  const button = $('login-submit');
  setBusy(button, true, '登录中');
  try {
    const data = await api('/api/login', { method: 'POST', body: { email, password, authCode } });
    if (data.need2FA) {
      $('login-code-field').classList.remove('hidden');
      $('login-code').focus();
      $('login-hint').textContent = '该账号开启了双重验证，请输入设备上收到的 6 位验证码后再次点击登录。';
      toast('需要双重验证码');
      return;
    }
    $('login-modal').classList.add('hidden');
    $('login-password').value = '';
    $('login-code').value = '';
    toast('登录成功', 'ok');
    await refreshState();
    state.purchasePage = 1;
    loadPurchases();
  } catch (err) {
    error.textContent = err.message;
    error.classList.remove('hidden');
  } finally {
    setBusy(button, false);
  }
}

$('logout-btn').addEventListener('click', async () => {
  if (!confirm('确定要退出登录并清除本机保存的凭据吗？')) return;
  try {
    await api('/api/logout', { method: 'POST' });
    toast('已退出登录', 'ok');
    await refreshState();
  } catch (err) {
    toast(err.message, 'err');
  }
});

/* ---------------- 下载 ---------------- */
async function startDownload(app, versionId, button) {
  setBusy(button, true, '开始');
  try {
    const body = {
      appId: app.trackId || 0,
      bundleId: app.bundleId || '',
      versionId: versionId || '',
      platform: $('search-platform').value,
      acquireLicense: true,
    };
    await api('/api/download', { method: 'POST', body: body });
    toast('已开始下载：' + (app.trackName || app.bundleId), 'ok');
    document.querySelector('.nav-item[data-view="tasks"]').click();
    pollTask();
  } catch (err) {
    toast(err.message, 'err');
  } finally {
    setBusy(button, false);
  }
}

$('task-cancel').addEventListener('click', async () => {
  try {
    await api('/api/download/cancel', { method: 'POST' });
    toast('已请求取消');
  } catch (err) {
    toast(err.message, 'err');
  }
});

$('task-reveal').addEventListener('click', async () => {
  const target = state.currentTask && state.currentTask.dest ? state.currentTask.dest : '';
  try {
    await api('/api/reveal', { method: 'POST', body: { path: target } });
  } catch (err) {
    toast(err.message, 'err');
  }
});

function pollTask() {
  if (state.polling) return;
  state.polling = setInterval(refreshTask, 700);
  refreshTask();
}

async function refreshTask() {
  let task;
  try {
    task = await api('/api/download');
  } catch (err) {
    return;
  }
  state.currentTask = task;

  const hasTask = task.active || task.done || task.error;
  $('task-empty').classList.toggle('hidden', !!hasTask);
  $('task-body').classList.toggle('hidden', !hasTask);
  if (!hasTask) return;

  $('task-name').textContent = task.name || '下载任务';
  $('task-stage').textContent = task.stage || (task.active ? '进行中' : '');
  $('task-bar').style.width = Math.max(0, Math.min(100, task.percent || 0)) + '%';
  $('task-percent').textContent = (task.percent || 0).toFixed(1) + '%';
  $('task-bytes').textContent = task.total > 0
    ? formatBytes(task.current) + ' / ' + formatBytes(task.total)
    : formatBytes(task.current);
  $('task-dest').textContent = task.dest || '';
  $('task-cancel').disabled = !task.active;

  const error = $('task-error');
  if (task.error) {
    error.textContent = task.error;
    error.classList.remove('hidden');
  } else {
    error.classList.add('hidden');
  }

  if (task.done && !state.reported) {
    state.reported = task.dest;
    if (task.error) {
      toast('下载失败：' + task.error, 'err');
    } else {
      toast('下载完成：' + (task.dest || ''), 'ok');
    }
  }
  if (!task.done) state.reported = null;

  if (!task.active && task.done) {
    clearInterval(state.polling);
    state.polling = null;
  }
}

function formatBytes(bytes) {
  const value = Number(bytes) || 0;
  if (value < 1024) return value + ' B';
  const units = ['KB', 'MB', 'GB'];
  let v = value / 1024;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return v.toFixed(v >= 100 ? 0 : 1) + ' ' + units[i];
}

/* ---------------- 设置 ---------------- */
$('keychain-save').addEventListener('click', async (e) => {
  const passphrase = $('keychain-input').value;
  if (!passphrase) { toast('请输入钥匙串密码', 'err'); return; }
  setBusy(e.currentTarget, true, '保存中');
  try {
    await api('/api/keychain', { method: 'POST', body: { passphrase: passphrase } });
    $('keychain-input').value = '';
    toast('钥匙串密码已设置', 'ok');
    await refreshState();
  } catch (err) {
    toast(err.message, 'err');
  } finally {
    setBusy(e.currentTarget, false);
  }
});

$('outputdir-save').addEventListener('click', async (e) => {
  setBusy(e.currentTarget, true, '保存中');
  try {
    await api('/api/outputdir', { method: 'POST', body: { path: $('outputdir-input').value.trim() } });
    toast('下载目录已更新', 'ok');
    await refreshState();
  } catch (err) {
    toast(err.message, 'err');
  } finally {
    setBusy(e.currentTarget, false);
  }
});

$('outputdir-open').addEventListener('click', async () => {
  try {
    await api('/api/reveal', { method: 'POST', body: { path: '' } });
  } catch (err) {
    toast(err.message, 'err');
  }
});

/* ---------------- 启动 ---------------- */
(async function boot() {
  try {
    await refreshState();
    if (state.loggedIn) loadPurchases();
  } catch (err) {
    toast('初始化失败：' + err.message, 'err');
  }
  refreshTask();
})();
