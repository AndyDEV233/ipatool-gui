package cmd

import (
	"context"
	"embed"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/majd/ipatool/v2/pkg/appstore"
	"github.com/schollz/progressbar/v3"
	"github.com/spf13/cobra"
)

//go:embed webui
var guiWebAssets embed.FS

const guiKeychainHint = "请先在「设置」里填写本机钥匙串密码（用于加密保存 Apple ID 凭据）"

// guiCmd 提供中文图形界面。
func guiCmd() *cobra.Command {
	var (
		port      int
		noBrowser bool
	)

	cmd := &cobra.Command{
		Use:   "gui",
		Short: "启动中文图形界面",
		Long:  "启动本地图形界面，通过浏览器完成登录、搜索、下载和已购列表等操作。",
		RunE: func(cmd *cobra.Command, args []string) error {
			return runGUI(port, noBrowser)
		},
	}

	cmd.Flags().IntVar(&port, "port", 0, "监听端口，0 表示自动分配")
	cmd.Flags().BoolVar(&noBrowser, "no-browser", false, "启动后不自动打开浏览器")

	return cmd
}

type guiServer struct {
	mu         sync.Mutex
	passphrase string
	outputDir  string
	task       *guiTask
}

// guiDownloadRequest 是一次下载请求的参数。
type guiDownloadRequest struct {
	AppID          int64  `json:"appId"`
	BundleID       string `json:"bundleId"`
	VersionID      string `json:"versionId"`
	Platform       string `json:"platform"`
	AcquireLicense bool   `json:"acquireLicense"`
}

type guiTask struct {
	mu      sync.Mutex
	name    string
	stage   string
	active  bool
	done    bool
	percent float64
	current int64
	total   int64
	dest    string
	errMsg  string
	cancel  context.CancelFunc
}

type guiTaskSnapshot struct {
	Name    string  `json:"name"`
	Stage   string  `json:"stage"`
	Active  bool    `json:"active"`
	Done    bool    `json:"done"`
	Percent float64 `json:"percent"`
	Current int64   `json:"current"`
	Total   int64   `json:"total"`
	Dest    string  `json:"dest"`
	Error   string  `json:"error"`
}

type guiAccount struct {
	Name       string `json:"name"`
	Email      string `json:"email"`
	StoreFront string `json:"storeFront"`
}

func (t *guiTask) setStage(stage string) {
	t.mu.Lock()
	defer t.mu.Unlock()

	t.stage = stage
}

func (t *guiTask) setName(name string) {
	t.mu.Lock()
	defer t.mu.Unlock()

	t.name = name
}

func (t *guiTask) syncBar(bar *progressbar.ProgressBar) {
	state := bar.State()

	t.mu.Lock()
	defer t.mu.Unlock()

	t.percent = state.CurrentPercent
	t.current = int64(state.CurrentBytes)
	t.total = bar.GetMax64()
}

func (t *guiTask) snapshot() guiTaskSnapshot {
	t.mu.Lock()
	defer t.mu.Unlock()

	return guiTaskSnapshot{
		Name:    t.name,
		Stage:   t.stage,
		Active:  t.active,
		Done:    t.done,
		Percent: t.percent,
		Current: t.current,
		Total:   t.total,
		Dest:    t.dest,
		Error:   t.errMsg,
	}
}

func (t *guiTask) isActive() bool {
	t.mu.Lock()
	defer t.mu.Unlock()

	return t.active
}

func (t *guiTask) conclude(destination string, err error) {
	t.mu.Lock()
	defer t.mu.Unlock()

	t.active = false
	t.done = true

	if destination != "" {
		t.dest = destination
	}

	if err != nil {
		t.errMsg = guiErrorText(err)
		if t.stage == "" || t.stage == "下载中" {
			t.stage = "已结束"
		}

		return
	}

	t.percent = 100
	t.stage = "已完成"
}

// guiErrorText 把内部错误翻译成中文提示。
func guiErrorText(err error) string {
	if err == nil {
		return ""
	}

	switch {
	case errors.Is(err, appstore.ErrAuthCodeRequired):
		return "该账号需要双重验证码，请填写验证码后重试"
	case errors.Is(err, appstore.ErrPasswordTokenExpired):
		return "登录状态已失效，请重新登录 Apple ID"
	case errors.Is(err, appstore.ErrLicenseRequired):
		return "该应用需要先获取许可（本工具仅支持免费应用）"
	case errors.Is(err, appstore.ErrLicenseAlreadyExists):
		return "该应用已在你的账号中"
	}

	message := err.Error()
	if strings.Contains(message, "keychain passphrase is required") {
		return guiKeychainHint
	}
	if strings.Contains(message, "failed to get account") {
		return "尚未登录 Apple ID，请先登录"
	}

	return message
}

func runGUI(port int, noBrowser bool) error {
	server := &guiServer{}

	// 图形界面下不通过终端索要钥匙串密码，避免程序卡在标准输入上。
	server.configureKeychain("")

	sub, err := fs.Sub(guiWebAssets, "webui")
	if err != nil {
		return fmt.Errorf("failed to load interface assets: %w", err)
	}

	listener, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", port))
	if err != nil {
		return fmt.Errorf("failed to listen on a local port: %w", err)
	}

	address, ok := listener.Addr().(*net.TCPAddr)
	if !ok {
		return errors.New("failed to resolve the listening address")
	}

	url := fmt.Sprintf("http://127.0.0.1:%d/", address.Port)

	mux := http.NewServeMux()
	mux.Handle("/", http.FileServer(http.FS(sub)))
	mux.HandleFunc("/api/state", server.handleState)
	mux.HandleFunc("/api/keychain", server.handleKeychain)
	mux.HandleFunc("/api/login", server.handleLogin)
	mux.HandleFunc("/api/logout", server.handleLogout)
	mux.HandleFunc("/api/search", server.handleSearch)
	mux.HandleFunc("/api/versions", server.handleVersions)
	mux.HandleFunc("/api/purchases", server.handlePurchases)
	mux.HandleFunc("/api/purchase", server.handlePurchase)
	mux.HandleFunc("/api/download", server.handleDownload)
	mux.HandleFunc("/api/download/cancel", server.handleDownloadCancel)
	mux.HandleFunc("/api/outputdir", server.handleOutputDir)
	mux.HandleFunc("/api/reveal", server.handleReveal)

	fmt.Printf("IPA 下载器已启动：%s\n", url)
	fmt.Println("关闭这个窗口即可退出程序。")

	if !noBrowser {
		openBrowser(url)
	}

	// nolint:wrapcheck
	return http.Serve(listener, mux)
}

// configureKeychain 使用指定口令重新装配依赖；口令为空时不会向终端索要。
func (s *guiServer) configureKeychain(passphrase string) {
	keychainPassphrase = passphrase

	s.mu.Lock()
	s.passphrase = passphrase
	s.mu.Unlock()

	stateDirectory, err := prepareStateDirectory(dependencies.OS, dependencies.Machine.HomeDirectory())
	if err != nil {
		return
	}

	dependencies.Keychain = newKeychain(stateDirectory, false)
	dependencies.AppStore = appstore.NewAppStore(appstore.Args{
		CookieJar:       dependencies.CookieJar,
		OperatingSystem: dependencies.OS,
		Keychain:        dependencies.Keychain,
		Machine:         dependencies.Machine,
	})
}

func (s *guiServer) hasPassphrase() bool {
	s.mu.Lock()
	defer s.mu.Unlock()

	return s.passphrase != ""
}

func (s *guiServer) account() (appstore.Account, error) {
	if !s.hasPassphrase() {
		return appstore.Account{}, errors.New(guiKeychainHint)
	}

	output, err := dependencies.AppStore.AccountInfo()
	if err != nil {
		return appstore.Account{}, err
	}

	return output.Account, nil
}

func (s *guiServer) currentOutputDir() string {
	s.mu.Lock()
	defer s.mu.Unlock()

	return s.outputDir
}

func (s *guiServer) effectiveOutputDir() string {
	if dir := s.currentOutputDir(); dir != "" {
		return dir
	}

	if workingDirectory, err := os.Getwd(); err == nil {
		return workingDirectory
	}

	return "."
}

/* ---------------- HTTP 辅助 ---------------- */

func writeJSON(writer http.ResponseWriter, status int, payload interface{}) {
	writer.Header().Set("Content-Type", "application/json; charset=utf-8")
	writer.WriteHeader(status)
	_ = json.NewEncoder(writer).Encode(payload)
}

func writeError(writer http.ResponseWriter, err error) {
	writeJSON(writer, http.StatusBadRequest, map[string]string{"error": guiErrorText(err)})
}

/* ---------------- 处理函数 ---------------- */

func (s *guiServer) handleState(writer http.ResponseWriter, request *http.Request) {
	payload := map[string]interface{}{
		"keychainConfigured": s.hasPassphrase(),
		"loggedIn":           false,
		"account":            nil,
		"outputDir":          s.currentOutputDir(),
		"effectiveOutputDir": s.effectiveOutputDir(),
		"version":            version,
	}

	if account, err := s.account(); err == nil {
		payload["loggedIn"] = true
		payload["account"] = guiAccount{
			Name:       account.Name,
			Email:      account.Email,
			StoreFront: account.StoreFront,
		}
	}

	writeJSON(writer, http.StatusOK, payload)
}

func (s *guiServer) handleKeychain(writer http.ResponseWriter, request *http.Request) {
	var body struct {
		Passphrase string `json:"passphrase"`
	}

	if err := json.NewDecoder(request.Body).Decode(&body); err != nil {
		writeError(writer, err)
		return
	}

	if body.Passphrase == "" {
		writeError(writer, errors.New("钥匙串密码不能为空"))
		return
	}

	s.configureKeychain(body.Passphrase)
	writeJSON(writer, http.StatusOK, map[string]bool{"ok": true})
}

func (s *guiServer) handleLogin(writer http.ResponseWriter, request *http.Request) {
	var body struct {
		Email    string `json:"email"`
		Password string `json:"password"`
		AuthCode string `json:"authCode"`
	}

	if err := json.NewDecoder(request.Body).Decode(&body); err != nil {
		writeError(writer, err)
		return
	}

	if !s.hasPassphrase() {
		writeError(writer, errors.New(guiKeychainHint))
		return
	}

	if body.Email == "" {
		writeError(writer, errors.New("请输入 Apple ID 邮箱"))
		return
	}

	output, err := dependencies.AppStore.Login(appstore.LoginInput{
		Email:    body.Email,
		Password: body.Password,
		AuthCode: body.AuthCode,
	})
	if err != nil {
		if errors.Is(err, appstore.ErrAuthCodeRequired) {
			writeJSON(writer, http.StatusOK, map[string]interface{}{"ok": false, "need2FA": true})
			return
		}

		writeError(writer, err)
		return
	}

	writeJSON(writer, http.StatusOK, map[string]interface{}{
		"ok":      true,
		"need2FA": false,
		"account": guiAccount{
			Name:       output.Account.Name,
			Email:      output.Account.Email,
			StoreFront: output.Account.StoreFront,
		},
	})
}

func (s *guiServer) handleLogout(writer http.ResponseWriter, request *http.Request) {
	if err := dependencies.AppStore.Revoke(); err != nil {
		writeError(writer, err)
		return
	}

	writeJSON(writer, http.StatusOK, map[string]bool{"ok": true})
}

func (s *guiServer) handleSearch(writer http.ResponseWriter, request *http.Request) {
	account, err := s.account()
	if err != nil {
		writeError(writer, err)
		return
	}

	platform, err := appstore.ParsePlatform(request.URL.Query().Get("platform"))
	if err != nil {
		writeError(writer, err)
		return
	}

	limit, err := strconv.ParseInt(request.URL.Query().Get("limit"), 10, 64)
	if err != nil || limit <= 0 {
		limit = 10
	}

	output, err := dependencies.AppStore.Search(appstore.SearchInput{
		Account:  account,
		Term:     request.URL.Query().Get("term"),
		Limit:    limit,
		Platform: platform,
	})
	if err != nil {
		writeError(writer, err)
		return
	}

	writeJSON(writer, http.StatusOK, map[string]interface{}{
		"count": output.Count,
		"apps":  output.Results,
	})
}

func (s *guiServer) handleVersions(writer http.ResponseWriter, request *http.Request) {
	account, err := s.account()
	if err != nil {
		writeError(writer, err)
		return
	}

	platform, err := appstore.ParsePlatform(request.URL.Query().Get("platform"))
	if err != nil {
		writeError(writer, err)
		return
	}

	app, err := s.resolveApp(account, request.URL.Query().Get("appId"), request.URL.Query().Get("bundleId"), platform)
	if err != nil {
		writeError(writer, err)
		return
	}

	output, err := dependencies.AppStore.ListVersions(appstore.ListVersionsInput{
		Account:  account,
		App:      app,
		Platform: platform,
	})
	if err != nil {
		writeError(writer, err)
		return
	}

	writeJSON(writer, http.StatusOK, map[string]interface{}{
		"latest": output.LatestExternalVersionID,
		"ids":    output.ExternalVersionIdentifiers,
	})
}

func (s *guiServer) handlePurchases(writer http.ResponseWriter, request *http.Request) {
	account, err := s.account()
	if err != nil {
		writeError(writer, err)
		return
	}

	platform, err := appstore.ParsePlatform(request.URL.Query().Get("platform"))
	if err != nil {
		writeError(writer, err)
		return
	}

	page, err := strconv.Atoi(request.URL.Query().Get("page"))
	if err != nil || page < 1 {
		page = 1
	}

	limit, err := strconv.Atoi(request.URL.Query().Get("limit"))
	if err != nil || limit < 1 {
		limit = appstore.DefaultOwnedAppsLimit
	}
	if limit > appstore.MaxOwnedAppsLimit {
		limit = appstore.MaxOwnedAppsLimit
	}

	output, err := dependencies.AppStore.OwnedApps(appstore.OwnedAppsInput{
		Account:  account,
		Page:     page,
		Limit:    limit,
		Platform: platform,
	})
	if err != nil {
		writeError(writer, err)
		return
	}

	writeJSON(writer, http.StatusOK, map[string]interface{}{
		"count":      output.Count,
		"totalCount": output.TotalCount,
		"page":       output.Page,
		"apps":       output.Results,
	})
}

func (s *guiServer) handlePurchase(writer http.ResponseWriter, request *http.Request) {
	var body struct {
		AppID    int64  `json:"appId"`
		BundleID string `json:"bundleId"`
		Platform string `json:"platform"`
	}

	if err := json.NewDecoder(request.Body).Decode(&body); err != nil {
		writeError(writer, err)
		return
	}

	account, err := s.account()
	if err != nil {
		writeError(writer, err)
		return
	}

	platform, err := appstore.ParsePlatform(body.Platform)
	if err != nil {
		writeError(writer, err)
		return
	}

	app, err := s.resolveApp(account, strconv.FormatInt(body.AppID, 10), body.BundleID, platform)
	if err != nil {
		writeError(writer, err)
		return
	}

	err = dependencies.AppStore.Purchase(appstore.PurchaseInput{
		Account:  account,
		App:      app,
		Platform: platform,
	})
	if err != nil && !errors.Is(err, appstore.ErrLicenseAlreadyExists) {
		writeError(writer, err)
		return
	}

	writeJSON(writer, http.StatusOK, map[string]bool{"ok": true})
}

func (s *guiServer) handleDownload(writer http.ResponseWriter, request *http.Request) {
	if request.Method != http.MethodPost {
		s.mu.Lock()
		task := s.task
		s.mu.Unlock()

		if task == nil {
			writeJSON(writer, http.StatusOK, guiTaskSnapshot{})
			return
		}

		writeJSON(writer, http.StatusOK, task.snapshot())
		return
	}

	var body guiDownloadRequest

	if err := json.NewDecoder(request.Body).Decode(&body); err != nil {
		writeError(writer, err)
		return
	}

	if body.AppID == 0 && body.BundleID == "" {
		writeError(writer, errors.New("缺少应用 ID 或 Bundle ID"))
		return
	}

	s.mu.Lock()
	if s.task != nil && s.task.isActive() {
		s.mu.Unlock()
		writeError(writer, errors.New("已有下载任务正在进行，请等待完成或取消"))
		return
	}

	ctx, cancel := context.WithCancel(context.Background())
	task := &guiTask{
		name:   body.BundleID,
		stage:  "准备中",
		active: true,
		cancel: cancel,
	}
	s.task = task
	s.mu.Unlock()

	go s.runDownload(ctx, task, body)

	writeJSON(writer, http.StatusOK, map[string]bool{"ok": true})
}

func (s *guiServer) handleDownloadCancel(writer http.ResponseWriter, request *http.Request) {
	s.mu.Lock()
	task := s.task
	s.mu.Unlock()

	if task != nil && task.isActive() {
		task.setStage("正在取消")
		task.cancel()
	}

	writeJSON(writer, http.StatusOK, map[string]bool{"ok": true})
}

func (s *guiServer) handleOutputDir(writer http.ResponseWriter, request *http.Request) {
	var body struct {
		Path string `json:"path"`
	}

	if err := json.NewDecoder(request.Body).Decode(&body); err != nil {
		writeError(writer, err)
		return
	}

	if body.Path != "" {
		info, err := os.Stat(body.Path)
		if err != nil || !info.IsDir() {
			writeError(writer, errors.New("目录不存在："+body.Path))
			return
		}
	}

	s.mu.Lock()
	s.outputDir = body.Path
	s.mu.Unlock()

	writeJSON(writer, http.StatusOK, map[string]interface{}{"ok": true, "outputDir": body.Path})
}

func (s *guiServer) handleReveal(writer http.ResponseWriter, request *http.Request) {
	var body struct {
		Path string `json:"path"`
	}

	if err := json.NewDecoder(request.Body).Decode(&body); err != nil {
		writeError(writer, err)
		return
	}

	target := body.Path
	if target == "" {
		target = s.effectiveOutputDir()
	}

	if err := revealInFileManager(target); err != nil {
		writeError(writer, err)
		return
	}

	writeJSON(writer, http.StatusOK, map[string]bool{"ok": true})
}

/* ---------------- 业务辅助 ---------------- */

func (s *guiServer) resolveApp(
	account appstore.Account,
	appID string,
	bundleID string,
	platform appstore.Platform,
) (appstore.App, error) {
	app := appstore.App{}

	if parsed, err := strconv.ParseInt(appID, 10, 64); err == nil {
		app.ID = parsed
	}

	if bundleID == "" {
		if app.ID == 0 {
			return appstore.App{}, errors.New("缺少应用 ID 或 Bundle ID")
		}

		return app, nil
	}

	output, err := dependencies.AppStore.Lookup(appstore.LookupInput{
		Account:  account,
		BundleID: bundleID,
		Platform: platform,
	})
	if err != nil {
		return appstore.App{}, err
	}

	return output.App, nil
}

func (s *guiServer) runDownload(ctx context.Context, task *guiTask, body guiDownloadRequest) {
	var (
		destination string
		runErr      error
	)

	defer func() {
		if recovered := recover(); recovered != nil {
			runErr = fmt.Errorf("任务异常：%v", recovered)
		}

		task.conclude(destination, runErr)
	}()

	runErr = s.performDownload(ctx, task, body, &destination)
}

func (s *guiServer) performDownload(
	ctx context.Context,
	task *guiTask,
	body guiDownloadRequest,
	destination *string,
) error {
	platform, err := appstore.ParsePlatform(body.Platform)
	if err != nil {
		task.setStage("参数错误")

		return err
	}

	account, err := s.account()
	if err != nil {
		task.setStage("未登录")

		return err
	}

	app, err := s.resolveApp(account, strconv.FormatInt(body.AppID, 10), body.BundleID, platform)
	if err != nil {
		task.setStage("查询应用失败")

		return err
	}

	name := app.Name
	if name == "" {
		name = app.BundleID
	}
	task.setName(name)

	bar := progressbar.NewOptions64(1,
		progressbar.OptionSetWriter(io.Discard),
		progressbar.OptionShowBytes(true),
		progressbar.OptionSetWidth(20),
		progressbar.OptionThrottle(80*time.Millisecond),
		progressbar.OptionSetPredictTime(false),
		progressbar.OptionSetElapsedTime(false),
		progressbar.OptionSetRenderBlankState(false),
	)

	stop := make(chan struct{})
	drained := make(chan struct{})

	go func() {
		defer close(drained)

		ticker := time.NewTicker(200 * time.Millisecond)
		defer ticker.Stop()

		for {
			select {
			case <-stop:
				return
			case <-ticker.C:
				task.syncBar(bar)
			}
		}
	}()

	defer func() {
		close(stop)
		<-drained
		task.syncBar(bar)
	}()

	task.setStage("下载中")

	input := appstore.DownloadInput{
		Context:           ctx,
		Account:           account,
		App:               app,
		OutputPath:        s.currentOutputDir(),
		Progress:          bar,
		ExternalVersionID: body.VersionID,
		Platform:          platform,
	}

	output, err := dependencies.AppStore.Download(input)

	if errors.Is(err, appstore.ErrLicenseRequired) && body.AcquireLicense {
		task.setStage("正在获取许可")

		purchaseError := dependencies.AppStore.Purchase(appstore.PurchaseInput{
			Account:  account,
			App:      app,
			Platform: platform,
		})
		if purchaseError != nil && !errors.Is(purchaseError, appstore.ErrLicenseAlreadyExists) {
			task.setStage("获取许可失败")

			return purchaseError
		}

		task.setStage("下载中")
		output, err = dependencies.AppStore.Download(input)
	}

	if errors.Is(err, appstore.ErrPasswordTokenExpired) {
		task.setStage("登录已过期，正在重新登录")

		loginOutput, loginError := dependencies.AppStore.Login(appstore.LoginInput{
			Email:    account.Email,
			Password: account.Password,
		})
		if loginError != nil {
			task.setStage("重新登录失败")

			return loginError
		}

		input.Account = loginOutput.Account
		task.setStage("下载中")
		output, err = dependencies.AppStore.Download(input)
	}

	if err != nil {
		task.setStage("下载失败")

		return err
	}

	if err := replicateDownloadSinf(dependencies.AppStore, platform, output); err != nil {
		task.setStage("写入授权信息失败")

		return err
	}

	*destination = output.DestinationPath

	return nil
}

func openBrowser(url string) {
	var command *exec.Cmd

	switch runtime.GOOS {
	case "windows":
		command = exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	case "darwin":
		command = exec.Command("open", url)
	default:
		command = exec.Command("xdg-open", url)
	}

	_ = command.Start()
}

func revealInFileManager(path string) error {
	info, err := os.Stat(path)
	if err != nil {
		return fmt.Errorf("路径不存在：%s", path)
	}

	var command *exec.Cmd

	switch runtime.GOOS {
	case "windows":
		if info.IsDir() {
			command = exec.Command("explorer", filepath.Clean(path))
		} else {
			command = exec.Command("explorer", "/select,"+filepath.Clean(path))
		}
	case "darwin":
		if info.IsDir() {
			command = exec.Command("open", path)
		} else {
			command = exec.Command("open", "-R", path)
		}
	default:
		command = exec.Command("xdg-open", path)
	}

	return command.Start() // nolint:wrapcheck
}
