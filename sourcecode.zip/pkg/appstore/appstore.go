package appstore

import (
	"time"

	"github.com/majd/ipatool/v2/pkg/http"
	"github.com/majd/ipatool/v2/pkg/keychain"
	"github.com/majd/ipatool/v2/pkg/util/machine"
	"github.com/majd/ipatool/v2/pkg/util/operatingsystem"
)

type AppStore interface {
	// Login authenticates with the App Store.
	Login(input LoginInput) (LoginOutput, error)
	// AccountInfo returns the information of the authenticated account.
	AccountInfo() (AccountInfoOutput, error)
	// Revoke revokes the active credentials.
	Revoke() error
	// Lookup looks apps up based on the specified bundle identifier.
	Lookup(input LookupInput) (LookupOutput, error)
	// Search searches the App Store for apps matching the specified term.
	Search(input SearchInput) (SearchOutput, error)
	// OwnedApps lists apps owned by the authenticated account.
	OwnedApps(input OwnedAppsInput) (OwnedAppsOutput, error)
	// Purchase acquires a license for the desired app.
	// Note: only free apps are supported.
	Purchase(input PurchaseInput) error
	// Download downloads the app package from the App Store to the desired location.
	Download(input DownloadInput) (DownloadOutput, error)
	// ReplicateSinf replicates the sinf for the IPA package.
	ReplicateSinf(input ReplicateSinfInput) error
	// VersionHistory lists the available versions of the specified app.
	ListVersions(input ListVersionsInput) (ListVersionsOutput, error)
	// GetVersionMetadata returns the metadata for the specified version.
	GetVersionMetadata(input GetVersionMetadataInput) (GetVersionMetadataOutput, error)
	// Bag fetches the bag which contains endpoint definitions.
	Bag(input BagInput) (BagOutput, error)
}

type appstore struct {
	keychain            keychain.Keychain
	loginClient         http.Client[loginResult]
	searchClient        http.Client[searchResult]
	purchaseClient      http.Client[purchaseResult]
	downloadClient      http.Client[downloadResult]
	platformClient      http.Client[platformVersionLookupResult]
	storefrontClient    http.Client[[]byte]
	bagClient           http.Client[bagResult]
	ownedAppsClient     http.Client[[]byte]
	httpClient          http.Client[interface{}]
	macDecrypterFactory macPackageDecrypterFactory
	actionSignerFactory ActionSignerFactory
	authRetrySleep      func(time.Duration)
	machine             machine.Machine
	os                  operatingsystem.OperatingSystem
}

type Args struct {
	Keychain            keychain.Keychain
	CookieJar           http.CookieJar
	OperatingSystem     operatingsystem.OperatingSystem
	Machine             machine.Machine
	ActionSignerFactory ActionSignerFactory
}

func NewAppStore(args Args) AppStore {
	clientArgs := http.Args{
		CookieJar: args.CookieJar,
	}

	actionSignerFactory := args.ActionSignerFactory
	if actionSignerFactory == nil {
		actionSignerFactory = defaultActionSignerFactory
	}

	return &appstore{
		keychain:            args.Keychain,
		loginClient:         http.NewClient[loginResult](http.Args{CookieJar: args.CookieJar, Authentication: true}),
		searchClient:        http.NewClient[searchResult](clientArgs),
		purchaseClient:      http.NewClient[purchaseResult](clientArgs),
		downloadClient:      http.NewClient[downloadResult](clientArgs),
		platformClient:      http.NewClient[platformVersionLookupResult](clientArgs),
		storefrontClient:    http.NewClient[[]byte](clientArgs),
		bagClient:           http.NewClient[bagResult](clientArgs),
		ownedAppsClient:     http.NewClient[[]byte](clientArgs),
		httpClient:          http.NewClient[interface{}](clientArgs),
		macDecrypterFactory: defaultMacPackageDecrypterFactory,
		actionSignerFactory: actionSignerFactory,
		authRetrySleep:      time.Sleep,
		machine:             args.Machine,
		os:                  args.OperatingSystem,
	}
}
