package appstore

import (
	"time"

	"github.com/rs/zerolog"
)

type App struct {
	ID           int64      `json:"trackId,omitempty"`
	BundleID     string     `json:"bundleId,omitempty"`
	Name         string     `json:"trackName,omitempty"`
	Version      string     `json:"version,omitempty"`
	Price        float64    `json:"price,omitempty"`
	PurchaseDate time.Time  `json:"purchaseDate,omitzero"`
	Platforms    []Platform `json:"platforms,omitzero"`
}

type VersionHistoryInfo struct {
	App                App
	LatestVersion      string
	VersionIdentifiers []string
}

type VersionDetails struct {
	VersionID     string
	VersionString string
	Success       bool
	Error         string
}

type Apps []App

func (apps Apps) MarshalZerologArray(a *zerolog.Array) {
	for _, app := range apps {
		a.Object(app)
	}
}

func (a App) MarshalZerologObject(event *zerolog.Event) {
	event.
		Int64("id", a.ID).
		Str("bundleID", a.BundleID).
		Str("name", a.Name).
		Str("version", a.Version).
		Float64("price", a.Price)

	if !a.PurchaseDate.IsZero() {
		event.Time("purchaseDate", a.PurchaseDate)
	}

	if a.Platforms != nil {
		platforms := make([]string, len(a.Platforms))
		for index, platform := range a.Platforms {
			platforms[index] = string(platform)
		}

		event.Strs("platforms", platforms)
	}
}
